import Foundation

//1) четное ли число
func even (value: Int) -> String {
    let isValueTwo = value%2
    if isValueTwo == 0  {
        return "введенное число четное"
    } else {
        return "введенное число нечетное"
}
}

even(value: 10)
even(value: 11)


//2) делится ли число на 3 без остатка
func tripple (value: Int) -> String {
    let isValueThree = value%3
    if isValueThree == 0  {
        return "введенное число делится на 3 без остатка"
    } else {
        return "введенное число не делится на 3 без остатка"
}
}

tripple (value: 199)
tripple (value: 972)

//3) создать возрастающий массив из 100 чисел
//вариант 1
var array = [Int]()
var element = 0
for _ in (1...100) {
   element += 1
    array.append(element)
}
array
//вариант 2
var array2 = [Int]()
for i in stride(from: 1, through: 200, by: 2) {
    array2.append(i)
}
array2

//4) Удалить из массива все четные числа и все числа, которые не делятся на 3
let n : Int = array.count
var arrayTwoThree = [Int]()
for i in stride(from: 1, through: n, by: 1) {
    if i%2 == 0 || i%3 == 0 {
    arrayTwoThree.append(i)
}
}
var arraySet = Set (array)
let arrayTwoThreeSet = Set (arrayTwoThree)
let arraySetNew = arraySet.subtracting(arrayTwoThreeSet).sorted()


// 5) Написать функцию, которая добавляет в массив новое число Фибоначчи (Fn=Fn-1 + Fn-2), и добавить 50 элементов

func fibonacci (countAdded: Int) -> Any {
    var a = 1
    var b = 1
    var fibarray = [a,b]
    for _ in (1...(countAdded-2)) {
        let c = a + b
        a = b
        b = c
        fibarray.append(c)
    }
   return fibarray
}

fibonacci(countAdded: 4)

