//домашняя работа 3
import Foundation

enum CarType: String {
    case sport = "спорт-кар", truck = "грузовик", family = "семейный SV"
    }
enum WindowState: String {
    case open = "Окна открыты", close = "Окна закрыты"
    }
enum Engine: String {
    case on = "двигатель заведен", off = "двигатель не заведен"
    }

struct SportCar {
    let carBrand: String
    let carType: CarType
    let carRelease: Int
    let trunkSize: Float
    var trunkLoad: Float
    var engineStatus: Engine {
        willSet {
            if newValue == .on {
                print ("Двигатель \(self.carBrand) включается")
            } else {
                print ("Двигатель \(self.carBrand) выключается")
            }
        }
    }
    var windowstate: WindowState
    let maxspeed: Int
    
    mutating func startEngine() {
        self.engineStatus = .on
    }
    mutating func endEngine() {
        self.engineStatus = .off
    }
}

        
struct TrunkCar {
    let carBrand: String
    let carType: CarType
    let carRelease: Int
    let trunkSize: Float
    var trunkLoad: Float {
        didSet {
            let newLoad = trunkLoad - oldValue
            if newLoad>0 {
                print ("В багажник догружено \(newLoad) килограмм, итоговый вес \(self.carBrand) составляет \(self.trunkLoad) килограмм")
            } else {
                let deloadCar = -newLoad
                print ("Из багажника выгружено \(deloadCar) килограмм, итоговый вес \(self.carBrand) составляет \(self.trunkLoad) килограмм")
            }
        }
    }
    
    let engine: Engine
    let windowstate: WindowState
    let wheelsNum: Int
    
    func printTrunkLoad () {
        print("в прицепе \(trunkLoad) килограмм")
    }
}


//Инициализировать несколько экземпляров структур
var car1 = SportCar(carBrand: "Ferrari", carType: .sport, carRelease: 2020, trunkSize: 100, trunkLoad: 0, engineStatus: .off, windowstate: .close, maxspeed: 270)
var car2 = TrunkCar(carBrand: "Mercedes", carType: .truck, carRelease: 2017, trunkSize: 600, trunkLoad: 60, engine: .off, windowstate: .close, wheelsNum: 8)

//Применить к ним различные действия
car1.startEngine()
car2.trunkLoad = 167
car2.printTrunkLoad()


