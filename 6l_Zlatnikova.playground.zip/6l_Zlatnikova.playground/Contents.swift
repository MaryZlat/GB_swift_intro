// Домашняя работа 6
import Foundation

struct QueueArray<T> {
    private var arrayElements: [T] = []
    
    mutating func enqueue(_ valueAdd: T) {
        arrayElements.append(valueAdd)
    }
    mutating func dequeue() -> T? {
        guard !arrayElements.isEmpty else {
            return nil
        }
        return arrayElements.removeFirst()
    }
    
    var firstElement: T? {
        return arrayElements.first
    }
    var lastElement: T? {
        return arrayElements.last
    }
    
    subscript(id: Int) -> T? {
        if id < 0 || id > arrayElements.count - 1 {
            return nil
        }
            return arrayElements[id]
    }
}

var queueTask = QueueArray<String>()
queueTask.enqueue("Send email")
queueTask.enqueue("Meeting at 1pm")
queueTask.enqueue("Lunch with Dan")
queueTask.dequeue()
queueTask.firstElement
queueTask[4]

var queueDates = QueueArray<Int>()
queueDates.dequeue()
queueDates.enqueue(23)
queueDates.enqueue(12)
queueDates.lastElement

