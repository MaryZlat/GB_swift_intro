//домашняя работа 4 (классы)
import Foundation

enum CarType: String {
    case sport = "спорт-кар", truck = "грузовик", family = "семейный SV"
    }
enum WindowState: String {
    case open = "Окна открыты", close = "Окна закрыты"
    }
enum Engine: String {
    case on = "двигатель заведен", off = "двигатель не заведен"
    }

class Car {
    let carBrand: String
    let carType: CarType
    let carRelease: Int
    let engineStatus: Engine
    init(carBrand: String, carType: CarType, carRelease: Int, engineStatus: Engine) {
        self.carBrand = carBrand
        self.carType = carType
        self.carRelease = carRelease
        self.engineStatus = engineStatus
    }
    func CarInfo() {
    
    }
}

class TrunkCar: Car {
    let wheelsNum: Int
    let trunkSize: Float
    var trunkLoad: Float {
        didSet {
            let newLoad = trunkLoad - oldValue
            if newLoad>0 {
                print ("В багажник догружено \(newLoad) килограмм, итоговый вес \(self.carBrand) составляет \(self.trunkLoad) килограмм")
            } else {
                let deloadCar = -newLoad
                print ("Из багажника выгружено \(deloadCar) килограмм, итоговый вес \(self.carBrand) составляет \(self.trunkLoad) килограмм")
            }
        }
    }
    static var trunkCarCount = 0
    init(carBrand: String, carType: CarType, carRelease: Int, engineStatus: Engine, wheelsNum: Int, trunkSize: Float, trunkLoad: Float) {
        self.wheelsNum = wheelsNum
        self.trunkSize = trunkSize
        self.trunkLoad = trunkLoad
        super.init(carBrand: carBrand, carType: carType, carRelease: carRelease, engineStatus: engineStatus)
        TrunkCar.trunkCarCount += 1
    }
    deinit {
        TrunkCar.trunkCarCount -= 1
    }
    
    //переопределить метод действия с автомобилем в соответствии с его классом
    override func CarInfo() {
        print ("вместимость \(self.carBrand) составляет \(self.trunkSize) килограмм, текущая загрузка \(self.trunkLoad/self.trunkSize*100)%")
    }
}

class SportCar: Car {
    var windowState: WindowState
    let maxspeed: Int
    static var sportCarCount = 0
    init(carBrand: String, carType: CarType, carRelease: Int, engineStatus: Engine, windowState: WindowState, maxspeed: Int) {
        self.windowState = windowState
        self.maxspeed = maxspeed
        SportCar.sportCarCount += 1
        super.init(carBrand: carBrand, carType: carType, carRelease: carRelease, engineStatus: engineStatus)
    }
    deinit {
        SportCar.sportCarCount -= 1
    }
    
    
    func openWindow () {
        windowState = .open
        print ("окна \(self.carBrand) открыты")
    }
    func closeWindow () {
        windowState = .close
        print ("окна \(self.carBrand) закрыты")
    }
    //переопределить метод действия с автомобилем в соответствии с его классом
    override func CarInfo() {
        print ("максимальная скорость \(self.carBrand) составляет \(self.maxspeed) километров в час")
    }
}


//Создать несколько объектов каждого класса
var car1 = SportCar(carBrand: "Ferrari", carType: .sport, carRelease: 2020, engineStatus: .off, windowState: .close, maxspeed: 270)
var car2 = TrunkCar(carBrand: "Mercedes", carType: .truck, carRelease: 2017, engineStatus: .off, wheelsNum: 8, trunkSize: 600, trunkLoad: 60)
var car3: TrunkCar? = TrunkCar(carBrand: "Kamaz", carType: .truck, carRelease: 2010, engineStatus: .off, wheelsNum: 10, trunkSize: 800, trunkLoad: 600)

print("Количество спортивных машин на парковке: \(SportCar.sportCarCount)")
print("Количество грузовых машин на парковке: \(TrunkCar.trunkCarCount)")


//Применить к ним различные действия
car1.CarInfo()
car2.CarInfo()
car1.openWindow()

car3 = nil
print("Количество грузовых машин на парковке: \(TrunkCar.trunkCarCount)")
